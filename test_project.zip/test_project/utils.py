"""
Utility functions with security issues
"""
import os
import subprocess
import yaml

# VULNERABILITY: AWS credentials hardcoded
AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

def execute_system_command(cmd):
    """Command injection vulnerability"""
    # VULNERABILITY: Shell=True with user input
    result = subprocess.run(cmd, shell=True, capture_output=True)
    return result.stdout

def read_config(filename):
    """Path traversal vulnerability"""
    # VULNERABILITY: No path validation
    config_path = "/etc/app/config/" + filename
    with open(config_path, 'r') as f:
        return f.read()

def load_yaml_config(data):
    """YAML deserialization vulnerability"""
    # VULNERABILITY: yaml.load without SafeLoader
    return yaml.load(data)

def calculate_result(expression):
    """Code injection vulnerability"""
    # VULNERABILITY: eval with user input
    return eval(expression)

def delete_file(user_input):
    """Command injection"""
    # VULNERABILITY: os.system with user input
    os.system(f"rm -rf {user_input}")

# VULNERABILITY: Private key in code
PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA1234567890...
-----END RSA PRIVATE KEY-----"""