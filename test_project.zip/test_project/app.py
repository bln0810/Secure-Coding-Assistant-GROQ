"""
Vulnerable Flask Application - FOR TESTING ONLY
This contains intentional security vulnerabilities for demonstration
"""
import os
import pickle
import sqlite3
from flask import Flask, request, render_template_string

app = Flask(__name__)

# VULNERABILITY: Hardcoded secret key
app.secret_key = "super-secret-key-12345"

# VULNERABILITY: Hardcoded credentials
DB_PASSWORD = "admin123"
API_KEY = "sk-1234567890abcdefghij"

@app.route('/user')
def get_user():
    """SQL Injection vulnerability"""
    user_id = request.args.get('id')
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # VULNERABILITY: SQL Injection
    query = "SELECT * FROM users WHERE id = '" + user_id + "'"
    cursor.execute(query)
    
    result = cursor.fetchone()
    conn.close()
    return str(result)

@app.route('/search')
def search():
    """XSS vulnerability"""
    search_term = request.args.get('q', '')
    
    # VULNERABILITY: XSS - Reflected
    html = "<h1>Search Results for: " + search_term + "</h1>"
    return render_template_string(html)

@app.route('/file')
def read_file():
    """Path Traversal vulnerability"""
    filename = request.args.get('name')
    
    # VULNERABILITY: Path Traversal
    file_path = "/var/www/uploads/" + filename
    with open(file_path, 'r') as f:
        content = f.read()
    return content

@app.route('/eval')
def evaluate():
    """Code injection vulnerability"""
    expression = request.args.get('expr')
    
    # VULNERABILITY: Eval usage
    result = eval(expression)
    return str(result)

@app.route('/command')
def execute_command():
    """Command Injection vulnerability"""
    filename = request.args.get('file')
    
    # VULNERABILITY: Command Injection
    os.system(f"cat {filename}")
    return "Command executed"

if __name__ == '__main__':
    # VULNERABILITY: Debug mode in production
    app.run(debug=True, host='0.0.0.0')