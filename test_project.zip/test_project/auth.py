"""
Authentication module with security issues
"""
import hashlib
import random

# VULNERABILITY: Weak password storage
def hash_password(password):
    # Using MD5 - cryptographically broken
    return hashlib.md5(password.encode()).hexdigest()

def verify_password(password, hash):
    return hash_password(password) == hash

# VULNERABILITY: Hardcoded credentials
ADMIN_USER = "admin"
ADMIN_PASS = "password123"

def authenticate(username, password):
    # VULNERABILITY: Timing attack possible
    if username == ADMIN_USER and password == ADMIN_PASS:
        return True
    return False

# VULNERABILITY: Weak random for security
def generate_token():
    # Using random instead of secrets module
    return ''.join([str(random.randint(0, 9)) for _ in range(32)])

# VULNERABILITY: SQL injection in login
def login_user(conn, username, password):
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    cursor.execute(query)
    return cursor.fetchone()