"""
Database operations with vulnerabilities
"""
import sqlite3
import pickle

def get_user_by_id(user_id):
    """SQL Injection vulnerability"""
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    
    # VULNERABILITY: String concatenation in SQL
    query = "SELECT * FROM users WHERE id = " + str(user_id)
    cursor.execute(query)
    
    return cursor.fetchone()

def search_users(name):
    """Another SQL injection"""
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    
    # VULNERABILITY: Format string in SQL
    query = f"SELECT * FROM users WHERE name LIKE '%{name}%'"
    cursor.execute(query)
    
    return cursor.fetchall()

def save_object(obj, filename):
    """Insecure serialization"""
    # VULNERABILITY: Pickle serialization
    with open(filename, 'wb') as f:
        pickle.dump(obj, f)

def load_object(filename):
    """Insecure deserialization"""
    # VULNERABILITY: Pickle deserialization without validation
    with open(filename, 'rb') as f:
        return pickle.load(f)

# VULNERABILITY: Hardcoded database credentials
DATABASE_URL = "postgresql://admin:Admin123@localhost:5432/mydb"